﻿using System;

namespace Enigma.Exceptions
{

	public class EnigmaRotorsException : EnigmaException
	{
	}

}
