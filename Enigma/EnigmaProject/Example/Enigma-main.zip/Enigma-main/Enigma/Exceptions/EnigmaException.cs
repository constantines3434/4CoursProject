﻿using System;

namespace Enigma.Exceptions
{
	public class EnigmaException : Exception
	{

		public EnigmaException() : base("Enigma general error")
		{
		}

	}
}
